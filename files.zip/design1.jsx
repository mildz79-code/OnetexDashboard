import { useState, useEffect } from "react";
import { BarChart, Bar, LineChart, Line, AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const profitData = [
  { month: "Aug", revenue: 42000, cost: 28000, profit: 14000 },
  { month: "Sep", revenue: 48000, cost: 30000, profit: 18000 },
  { month: "Oct", revenue: 51000, cost: 32000, profit: 19000 },
  { month: "Nov", revenue: 55000, cost: 31000, profit: 24000 },
  { month: "Dec", revenue: 62000, cost: 35000, profit: 27000 },
  { month: "Jan", revenue: 58000, cost: 33000, profit: 25000 },
  { month: "Feb", revenue: 67000, cost: 36000, profit: 31000 },
];

const orderData = [
  { id: "OT-4821", client: "Zara EU", style: "Linen Blazer", qty: 2400, status: "Cutting", progress: 35, due: "Mar 12" },
  { id: "OT-4822", client: "H&M Asia", style: "Cotton Tee V2", qty: 8000, status: "Sewing", progress: 62, due: "Mar 05" },
  { id: "OT-4823", client: "Uniqlo JP", style: "Fleece Pullover", qty: 5500, status: "QC", progress: 88, due: "Feb 28" },
  { id: "OT-4824", client: "Gap NA", style: "Denim Jacket", qty: 3200, status: "Packing", progress: 95, due: "Feb 27" },
  { id: "OT-4825", client: "Nike SG", style: "DryFit Polo", qty: 6000, status: "Fabric Prep", progress: 12, due: "Mar 22" },
];

const fabricStock = [
  { name: "Cotton", value: 35, color: "#F59E0B" },
  { name: "Polyester", value: 25, color: "#3B82F6" },
  { name: "Linen", value: 18, color: "#10B981" },
  { name: "Denim", value: 22, color: "#8B5CF6" },
];

const weeklyOutput = [
  { day: "Mon", units: 820 }, { day: "Tue", units: 950 }, { day: "Wed", units: 1100 },
  { day: "Thu", units: 980 }, { day: "Fri", units: 1250 }, { day: "Sat", units: 600 },
];

const statusColor = { "Fabric Prep": "#8B5CF6", "Cutting": "#F59E0B", "Sewing": "#3B82F6", "QC": "#10B981", "Packing": "#EC4899" };

const menuItems = [
  { icon: "📊", label: "Dashboard", active: true },
  { icon: "📦", label: "Orders" },
  { icon: "🧵", label: "Production" },
  { icon: "📐", label: "Patterns" },
  { icon: "🏭", label: "Inventory" },
  { icon: "👥", label: "Workers" },
  { icon: "🚚", label: "Shipping" },
  { icon: "📈", label: "Analytics" },
  { icon: "⚙️", label: "Settings" },
];

export default function Design1() {
  const [loaded, setLoaded] = useState(false);
  const [activeMenu, setActiveMenu] = useState("Dashboard");

  useEffect(() => { setLoaded(true); }, []);

  return (
    <div style={{
      fontFamily: "'DM Mono', 'JetBrains Mono', monospace",
      background: "#0C0C0E",
      color: "#E4E4E7",
      minHeight: "100vh",
      display: "flex",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@300;400;500&family=Bebas+Neue&display=swap" rel="stylesheet" />
      
      {/* SIDEBAR */}
      <aside style={{
        width: 220,
        background: "linear-gradient(180deg, #141416 0%, #0C0C0E 100%)",
        borderRight: "1px solid #27272A",
        display: "flex",
        flexDirection: "column",
        padding: "0",
        flexShrink: 0,
      }}>
        <div style={{
          padding: "24px 20px",
          borderBottom: "1px solid #27272A",
        }}>
          <div style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: 28, letterSpacing: 3, color: "#F59E0B" }}>
            ONE<span style={{ color: "#E4E4E7" }}>TEXTILE</span>
          </div>
          <div style={{ fontSize: 10, color: "#71717A", letterSpacing: 2, marginTop: 4 }}>PRODUCTION HQ</div>
        </div>

        {/* Order Tracker WIP Banner */}
        <div style={{
          margin: "16px 12px",
          padding: "12px 14px",
          background: "linear-gradient(135deg, #F59E0B22, #F59E0B08)",
          border: "1px solid #F59E0B44",
          borderRadius: 6,
        }}>
          <div style={{ fontSize: 9, letterSpacing: 2, color: "#F59E0B", marginBottom: 6 }}>🔥 ORDER TRACKER</div>
          <div style={{ fontSize: 20, fontFamily: "'Bebas Neue'", color: "#F59E0B" }}>24 <span style={{ fontSize: 11, color: "#71717A" }}>ACTIVE</span></div>
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
            <span style={{ fontSize: 9, background: "#10B98133", color: "#10B981", padding: "2px 6px", borderRadius: 3 }}>8 ON TIME</span>
            <span style={{ fontSize: 9, background: "#EF444433", color: "#EF4444", padding: "2px 6px", borderRadius: 3 }}>3 LATE</span>
          </div>
        </div>

        {/* Profit Tracker Mini */}
        <div style={{
          margin: "0 12px 16px",
          padding: "12px 14px",
          background: "linear-gradient(135deg, #10B98122, #10B98108)",
          border: "1px solid #10B98144",
          borderRadius: 6,
        }}>
          <div style={{ fontSize: 9, letterSpacing: 2, color: "#10B981", marginBottom: 6 }}>💰 PROFIT TRACKER</div>
          <div style={{ fontSize: 20, fontFamily: "'Bebas Neue'", color: "#10B981" }}>$31K <span style={{ fontSize: 11, color: "#71717A" }}>FEB</span></div>
          <div style={{ fontSize: 9, color: "#10B981", marginTop: 4 }}>▲ 24% vs last month</div>
        </div>

        <nav style={{ flex: 1, padding: "0 8px" }}>
          {menuItems.map((item) => (
            <button
              key={item.label}
              onClick={() => setActiveMenu(item.label)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                width: "100%",
                padding: "10px 12px",
                background: activeMenu === item.label ? "#27272A" : "transparent",
                border: "none",
                borderRadius: 4,
                color: activeMenu === item.label ? "#F59E0B" : "#71717A",
                fontSize: 12,
                cursor: "pointer",
                letterSpacing: 1,
                marginBottom: 2,
                transition: "all 0.2s",
              }}
            >
              <span>{item.icon}</span>
              <span>{item.label.toUpperCase()}</span>
            </button>
          ))}
        </nav>

        <div style={{ padding: "16px 20px", borderTop: "1px solid #27272A", fontSize: 9, color: "#3F3F46" }}>
          v2.4.1 — INDUSTRIAL
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main style={{ flex: 1, padding: 28, overflow: "auto" }}>
        {/* Header */}
        <div style={{
          display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 28,
          opacity: loaded ? 1 : 0, transform: loaded ? "none" : "translateY(-10px)", transition: "all 0.5s ease",
        }}>
          <div>
            <h1 style={{ fontFamily: "'Bebas Neue'", fontSize: 42, letterSpacing: 4, margin: 0, lineHeight: 1 }}>
              PRODUCTION <span style={{ color: "#F59E0B" }}>DASHBOARD</span>
            </h1>
            <p style={{ fontSize: 11, color: "#52525B", letterSpacing: 2, marginTop: 6 }}>FEBRUARY 26, 2026 — REAL-TIME FLOOR DATA</p>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#10B981", boxShadow: "0 0 8px #10B981" }} />
            <span style={{ fontSize: 10, color: "#10B981", letterSpacing: 1 }}>ALL SYSTEMS ONLINE</span>
          </div>
        </div>

        {/* KPI Strip */}
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 28,
          opacity: loaded ? 1 : 0, transform: loaded ? "none" : "translateY(10px)", transition: "all 0.6s ease 0.1s",
        }}>
          {[
            { label: "MONTHLY REVENUE", value: "$67,000", change: "+15%", color: "#F59E0B", sub: "FEB 2026" },
            { label: "TOTAL PROFIT", value: "$31,000", change: "+24%", color: "#10B981", sub: "MARGIN 46.3%" },
            { label: "UNITS PRODUCED", value: "5,700", change: "+8%", color: "#3B82F6", sub: "THIS WEEK" },
            { label: "DEFECT RATE", value: "1.2%", change: "-0.3%", color: "#EC4899", sub: "TARGET <2%" },
          ].map((kpi, i) => (
            <div key={i} style={{
              background: "#141416",
              border: "1px solid #27272A",
              borderTop: `3px solid ${kpi.color}`,
              padding: "20px 18px",
              borderRadius: 4,
            }}>
              <div style={{ fontSize: 9, letterSpacing: 2, color: "#52525B", marginBottom: 10 }}>{kpi.label}</div>
              <div style={{ fontFamily: "'Bebas Neue'", fontSize: 36, color: kpi.color, lineHeight: 1 }}>{kpi.value}</div>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
                <span style={{ fontSize: 10, color: kpi.change.startsWith("+") || kpi.change.startsWith("-0") ? "#10B981" : "#EF4444" }}>{kpi.change}</span>
                <span style={{ fontSize: 9, color: "#3F3F46" }}>{kpi.sub}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Charts Row */}
        <div style={{
          display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16, marginBottom: 28,
          opacity: loaded ? 1 : 0, transition: "all 0.7s ease 0.2s",
        }}>
          {/* Profit Chart */}
          <div style={{ background: "#141416", border: "1px solid #27272A", borderRadius: 4, padding: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ fontSize: 10, letterSpacing: 2, color: "#71717A" }}>REVENUE vs COST vs PROFIT</div>
              <div style={{ display: "flex", gap: 12 }}>
                <span style={{ fontSize: 9, color: "#F59E0B" }}>■ REVENUE</span>
                <span style={{ fontSize: 9, color: "#EF4444" }}>■ COST</span>
                <span style={{ fontSize: 9, color: "#10B981" }}>■ PROFIT</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={profitData}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#F59E0B" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#F59E0B" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="profGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10B981" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#10B981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" tick={{ fill: "#52525B", fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#52525B", fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v/1000}k`} />
                <Tooltip contentStyle={{ background: "#1C1C1E", border: "1px solid #27272A", borderRadius: 4, fontSize: 11, color: "#E4E4E7" }} />
                <Area type="monotone" dataKey="revenue" stroke="#F59E0B" fill="url(#revGrad)" strokeWidth={2} />
                <Area type="monotone" dataKey="cost" stroke="#EF4444" fill="none" strokeWidth={1.5} strokeDasharray="4 4" />
                <Area type="monotone" dataKey="profit" stroke="#10B981" fill="url(#profGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Fabric Stock Pie */}
          <div style={{ background: "#141416", border: "1px solid #27272A", borderRadius: 4, padding: 20 }}>
            <div style={{ fontSize: 10, letterSpacing: 2, color: "#71717A", marginBottom: 16 }}>FABRIC STOCK MIX</div>
            <ResponsiveContainer width="100%" height={140}>
              <PieChart>
                <Pie data={fabricStock} dataKey="value" cx="50%" cy="50%" innerRadius={40} outerRadius={60} strokeWidth={0}>
                  {fabricStock.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 12 }}>
              {fabricStock.map((f) => (
                <span key={f.name} style={{ fontSize: 10, color: f.color }}>● {f.name} {f.value}%</span>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Row */}
        <div style={{
          display: "grid", gridTemplateColumns: "3fr 1fr", gap: 16,
          opacity: loaded ? 1 : 0, transition: "all 0.8s ease 0.3s",
        }}>
          {/* Order Table */}
          <div style={{ background: "#141416", border: "1px solid #27272A", borderRadius: 4, padding: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ fontSize: 10, letterSpacing: 2, color: "#71717A" }}>ACTIVE ORDERS — WIP TRACKER</div>
              <span style={{ fontSize: 9, background: "#F59E0B22", color: "#F59E0B", padding: "3px 8px", borderRadius: 3, letterSpacing: 1 }}>LIVE</span>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
              <thead>
                <tr style={{ borderBottom: "1px solid #27272A" }}>
                  {["ORDER", "CLIENT", "STYLE", "QTY", "STATUS", "PROGRESS", "DUE"].map((h) => (
                    <th key={h} style={{ textAlign: "left", padding: "8px 6px", color: "#52525B", fontSize: 9, letterSpacing: 2, fontWeight: 400 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {orderData.map((o) => (
                  <tr key={o.id} style={{ borderBottom: "1px solid #1C1C1E" }}>
                    <td style={{ padding: "10px 6px", color: "#F59E0B", fontWeight: 500 }}>{o.id}</td>
                    <td style={{ padding: "10px 6px" }}>{o.client}</td>
                    <td style={{ padding: "10px 6px", color: "#A1A1AA" }}>{o.style}</td>
                    <td style={{ padding: "10px 6px" }}>{o.qty.toLocaleString()}</td>
                    <td style={{ padding: "10px 6px" }}>
                      <span style={{ fontSize: 9, padding: "2px 8px", borderRadius: 3, background: `${statusColor[o.status]}22`, color: statusColor[o.status], letterSpacing: 1 }}>
                        {o.status.toUpperCase()}
                      </span>
                    </td>
                    <td style={{ padding: "10px 6px", width: 120 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div style={{ flex: 1, height: 4, background: "#27272A", borderRadius: 2, overflow: "hidden" }}>
                          <div style={{ width: `${o.progress}%`, height: "100%", background: statusColor[o.status], borderRadius: 2, transition: "width 1s ease" }} />
                        </div>
                        <span style={{ fontSize: 10, color: "#71717A", minWidth: 28 }}>{o.progress}%</span>
                      </div>
                    </td>
                    <td style={{ padding: "10px 6px", color: "#71717A", fontSize: 10 }}>{o.due}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Weekly Output */}
          <div style={{ background: "#141416", border: "1px solid #27272A", borderRadius: 4, padding: 20 }}>
            <div style={{ fontSize: 10, letterSpacing: 2, color: "#71717A", marginBottom: 16 }}>WEEKLY OUTPUT</div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={weeklyOutput}>
                <XAxis dataKey="day" tick={{ fill: "#52525B", fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip contentStyle={{ background: "#1C1C1E", border: "1px solid #27272A", borderRadius: 4, fontSize: 11, color: "#E4E4E7" }} />
                <Bar dataKey="units" fill="#3B82F6" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </main>
    </div>
  );
}
