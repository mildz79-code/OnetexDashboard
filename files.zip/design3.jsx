import { useState, useEffect } from "react";
import { BarChart, Bar, AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const profitData = [
  { month: "Aug", revenue: 42000, cost: 28000, profit: 14000 },
  { month: "Sep", revenue: 48000, cost: 30000, profit: 18000 },
  { month: "Oct", revenue: 51000, cost: 32000, profit: 19000 },
  { month: "Nov", revenue: 55000, cost: 31000, profit: 24000 },
  { month: "Dec", revenue: 62000, cost: 35000, profit: 27000 },
  { month: "Jan", revenue: 58000, cost: 33000, profit: 25000 },
  { month: "Feb", revenue: 67000, cost: 36000, profit: 31000 },
];

const orderData = [
  { id: "OT-4821", client: "Zara EU", style: "Linen Blazer", qty: 2400, status: "Cutting", progress: 35, due: "Mar 12" },
  { id: "OT-4822", client: "H&M Asia", style: "Cotton Tee V2", qty: 8000, status: "Sewing", progress: 62, due: "Mar 05" },
  { id: "OT-4823", client: "Uniqlo JP", style: "Fleece Pullover", qty: 5500, status: "QC", progress: 88, due: "Feb 28" },
  { id: "OT-4824", client: "Gap NA", style: "Denim Jacket", qty: 3200, status: "Packing", progress: 95, due: "Feb 27" },
  { id: "OT-4825", client: "Nike SG", style: "DryFit Polo", qty: 6000, status: "Fabric Prep", progress: 12, due: "Mar 22" },
];

const stageData = [
  { name: "Prep", value: 4, color: "#A78BFA" },
  { name: "Cut", value: 6, color: "#F472B6" },
  { name: "Sew", value: 8, color: "#38BDF8" },
  { name: "QC", value: 3, color: "#34D399" },
  { name: "Pack", value: 3, color: "#FBBF24" },
];

const hourlyOutput = [
  { h: "6AM", v: 120 }, { h: "8AM", v: 280 }, { h: "10AM", v: 420 },
  { h: "12PM", v: 350 }, { h: "2PM", v: 480 }, { h: "4PM", v: 390 }, { h: "6PM", v: 180 },
];

const statusGrad = {
  "Fabric Prep": ["#A78BFA", "#C4B5FD"],
  "Cutting": ["#F472B6", "#FBCFE8"],
  "Sewing": ["#38BDF8", "#7DD3FC"],
  "QC": ["#34D399", "#6EE7B7"],
  "Packing": ["#FBBF24", "#FDE68A"],
};

const menuItems = [
  { icon: "⬡", label: "Dashboard", active: true },
  { icon: "⬢", label: "Orders" },
  { icon: "◆", label: "Production" },
  { icon: "◇", label: "Patterns" },
  { icon: "▣", label: "Inventory" },
  { icon: "◉", label: "Workforce" },
  { icon: "▹", label: "Logistics" },
  { icon: "◈", label: "Insights" },
  { icon: "⚙", label: "Config" },
];

export default function Design3() {
  const [loaded, setLoaded] = useState(false);
  const [activeMenu, setActiveMenu] = useState("Dashboard");

  useEffect(() => { setTimeout(() => setLoaded(true), 100); }, []);

  const Glass = ({ children, style: s = {}, glow = false }) => (
    <div style={{
      background: "rgba(255,255,255,0.04)",
      backdropFilter: "blur(20px)",
      WebkitBackdropFilter: "blur(20px)",
      border: "1px solid rgba(255,255,255,0.08)",
      borderRadius: 16,
      padding: 22,
      position: "relative",
      overflow: "hidden",
      ...(glow ? { boxShadow: "0 0 40px rgba(56,189,248,0.06)" } : {}),
      ...s,
    }}>{children}</div>
  );

  return (
    <div style={{
      fontFamily: "'Outfit', 'Poppins', sans-serif",
      background: "linear-gradient(145deg, #0A0E1A 0%, #111827 40%, #0F172A 100%)",
      color: "#E2E8F0",
      minHeight: "100vh",
      display: "flex",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet" />
      
      {/* Ambient glow effects */}
      <div style={{
        position: "fixed", top: -200, right: -200, width: 500, height: 500,
        background: "radial-gradient(circle, rgba(56,189,248,0.08) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />
      <div style={{
        position: "fixed", bottom: -100, left: 200, width: 400, height: 400,
        background: "radial-gradient(circle, rgba(167,139,250,0.06) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />

      {/* SIDEBAR */}
      <aside style={{
        width: 250,
        background: "rgba(15,23,42,0.6)",
        backdropFilter: "blur(20px)",
        borderRight: "1px solid rgba(255,255,255,0.06)",
        display: "flex",
        flexDirection: "column",
        flexShrink: 0,
        zIndex: 10,
      }}>
        <div style={{ padding: "28px 24px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <div style={{
            fontSize: 24, fontWeight: 800, letterSpacing: -0.5,
            background: "linear-gradient(135deg, #38BDF8, #A78BFA, #F472B6)",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
          }}>
            OneTextile
          </div>
          <div style={{ fontSize: 11, color: "#475569", marginTop: 4, fontWeight: 300 }}>Production Intelligence</div>
        </div>

        {/* Order Tracker WIP */}
        <div style={{
          margin: "20px 14px 8px",
          padding: "18px",
          background: "linear-gradient(135deg, rgba(56,189,248,0.1), rgba(167,139,250,0.05))",
          borderRadius: 14,
          border: "1px solid rgba(56,189,248,0.15)",
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <span style={{ fontSize: 10, fontWeight: 600, color: "#38BDF8", letterSpacing: 1.5 }}>ORDERS · WIP</span>
            <span style={{ fontSize: 9, color: "#334155", background: "rgba(56,189,248,0.15)", padding: "2px 8px", borderRadius: 10 }}>LIVE</span>
          </div>
          <div style={{ fontSize: 36, fontWeight: 800, lineHeight: 1, background: "linear-gradient(135deg, #38BDF8, #A78BFA)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>24</div>
          <div style={{ display: "flex", gap: 6, marginTop: 12 }}>
            {stageData.map((s) => (
              <div key={s.name} style={{ flex: s.value, height: 4, borderRadius: 4, background: s.color, opacity: 0.7 }} />
            ))}
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
            {stageData.map((s) => (
              <span key={s.name} style={{ fontSize: 8, color: s.color }}>{s.name} {s.value}</span>
            ))}
          </div>
        </div>

        {/* Profit Mini */}
        <div style={{
          margin: "8px 14px 20px",
          padding: "18px",
          background: "linear-gradient(135deg, rgba(52,211,153,0.1), rgba(52,211,153,0.02))",
          borderRadius: 14,
          border: "1px solid rgba(52,211,153,0.15)",
        }}>
          <div style={{ fontSize: 10, fontWeight: 600, color: "#34D399", letterSpacing: 1.5, marginBottom: 8 }}>PROFIT TRACKER</div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
            <span style={{ fontSize: 28, fontWeight: 800, color: "#34D399" }}>$31K</span>
            <span style={{
              fontSize: 11, color: "#34D399", background: "rgba(52,211,153,0.15)", padding: "2px 8px", borderRadius: 8,
            }}>+24%</span>
          </div>
          <div style={{ fontSize: 11, color: "#475569", marginTop: 6 }}>46.3% margin · Feb 2026</div>
        </div>

        <nav style={{ flex: 1, padding: "0 10px" }}>
          {menuItems.map((item) => (
            <button
              key={item.label}
              onClick={() => setActiveMenu(item.label)}
              style={{
                display: "flex", alignItems: "center", gap: 14, width: "100%",
                padding: "11px 14px",
                background: activeMenu === item.label
                  ? "linear-gradient(135deg, rgba(56,189,248,0.12), rgba(167,139,250,0.08))"
                  : "transparent",
                border: activeMenu === item.label ? "1px solid rgba(56,189,248,0.15)" : "1px solid transparent",
                borderRadius: 10,
                color: activeMenu === item.label ? "#38BDF8" : "#475569",
                fontSize: 13, fontWeight: activeMenu === item.label ? 600 : 400,
                cursor: "pointer", marginBottom: 2, transition: "all 0.25s",
              }}
            >
              <span style={{ fontSize: 13 }}>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>
      </aside>

      {/* MAIN */}
      <main style={{ flex: 1, padding: 30, overflow: "auto", position: "relative", zIndex: 5 }}>
        <div style={{
          display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 30,
          opacity: loaded ? 1 : 0, transition: "opacity 0.5s ease",
        }}>
          <div>
            <h1 style={{ fontSize: 34, fontWeight: 800, margin: 0, letterSpacing: -1 }}>
              Production <span style={{
                background: "linear-gradient(135deg, #38BDF8, #A78BFA)",
                WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
              }}>Command Center</span>
            </h1>
            <p style={{ fontSize: 13, color: "#475569", marginTop: 6, fontWeight: 300 }}>Feb 26, 2026 · Real-time analytics</p>
          </div>
        </div>

        {/* KPIs */}
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 24,
          opacity: loaded ? 1 : 0, transform: loaded ? "none" : "translateY(15px)", transition: "all 0.6s ease 0.1s",
        }}>
          {[
            { label: "Revenue", val: "$67K", sub: "+15.3%", grad: ["#38BDF8", "#0EA5E9"] },
            { label: "Net Profit", val: "$31K", sub: "+24.0%", grad: ["#34D399", "#10B981"] },
            { label: "Units/Week", val: "5,700", sub: "+8.2%", grad: ["#A78BFA", "#8B5CF6"] },
            { label: "Defect Rate", val: "1.2%", sub: "−0.3pp", grad: ["#F472B6", "#EC4899"] },
          ].map((k, i) => (
            <Glass key={i} glow>
              <div style={{ fontSize: 11, color: "#64748B", fontWeight: 400, marginBottom: 8 }}>{k.label}</div>
              <div style={{
                fontSize: 34, fontWeight: 800, lineHeight: 1,
                background: `linear-gradient(135deg, ${k.grad[0]}, ${k.grad[1]})`,
                WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
              }}>{k.val}</div>
              <div style={{
                fontSize: 11, marginTop: 10, color: k.grad[0], fontWeight: 500,
              }}>{k.sub} <span style={{ color: "#475569", fontWeight: 300 }}>vs prev</span></div>
            </Glass>
          ))}
        </div>

        {/* Charts */}
        <div style={{
          display: "grid", gridTemplateColumns: "3fr 2fr", gap: 14, marginBottom: 24,
          opacity: loaded ? 1 : 0, transition: "all 0.7s ease 0.2s",
        }}>
          <Glass>
            <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 18, color: "#CBD5E1" }}>Revenue & Profit Trend</div>
            <ResponsiveContainer width="100%" height={230}>
              <AreaChart data={profitData}>
                <defs>
                  <linearGradient id="g3rev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#38BDF8" stopOpacity={0.25} />
                    <stop offset="100%" stopColor="#38BDF8" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="g3prof" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#34D399" stopOpacity={0.25} />
                    <stop offset="100%" stopColor="#34D399" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" tick={{ fill: "#475569", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#475569", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v/1000}k`} />
                <Tooltip contentStyle={{ background: "rgba(15,23,42,0.9)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, fontSize: 12, color: "#E2E8F0", backdropFilter: "blur(10px)" }} />
                <Area type="monotone" dataKey="revenue" stroke="#38BDF8" fill="url(#g3rev)" strokeWidth={2} />
                <Area type="monotone" dataKey="profit" stroke="#34D399" fill="url(#g3prof)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </Glass>

          <Glass>
            <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 18, color: "#CBD5E1" }}>Today's Output</div>
            <ResponsiveContainer width="100%" height={230}>
              <BarChart data={hourlyOutput}>
                <defs>
                  <linearGradient id="barGrad3" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#A78BFA" />
                    <stop offset="100%" stopColor="#38BDF8" />
                  </linearGradient>
                </defs>
                <XAxis dataKey="h" tick={{ fill: "#475569", fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip contentStyle={{ background: "rgba(15,23,42,0.9)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, fontSize: 12, color: "#E2E8F0" }} />
                <Bar dataKey="v" fill="url(#barGrad3)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Glass>
        </div>

        {/* Orders WIP */}
        <Glass style={{
          opacity: loaded ? 1 : 0, transition: "all 0.8s ease 0.3s", padding: 0, overflow: "hidden",
        }}>
          <div style={{ padding: "20px 22px 16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <span style={{ fontSize: 13, fontWeight: 600, color: "#CBD5E1" }}>Order Tracker</span>
              <span style={{ fontSize: 10, color: "#475569", marginLeft: 10 }}>Work in Progress</span>
            </div>
            <span style={{
              fontSize: 9, fontWeight: 600, letterSpacing: 1.5,
              background: "linear-gradient(135deg, #38BDF8, #A78BFA)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>REAL-TIME ●</span>
          </div>
          {orderData.map((o, idx) => (
            <div key={o.id} style={{
              display: "grid", gridTemplateColumns: "80px 95px 140px 65px 100px 1fr 65px",
              alignItems: "center", padding: "14px 22px", fontSize: 13,
              borderTop: "1px solid rgba(255,255,255,0.04)",
              transition: "background 0.2s",
            }}
              onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.03)"}
              onMouseLeave={e => e.currentTarget.style.background = "transparent"}
            >
              <span style={{ fontWeight: 600, background: `linear-gradient(135deg, ${statusGrad[o.status][0]}, ${statusGrad[o.status][1]})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>{o.id}</span>
              <span style={{ fontWeight: 500 }}>{o.client}</span>
              <span style={{ color: "#64748B" }}>{o.style}</span>
              <span>{o.qty.toLocaleString()}</span>
              <span style={{
                display: "inline-block", textAlign: "center",
                padding: "4px 10px", borderRadius: 8, fontSize: 10, fontWeight: 600,
                background: `linear-gradient(135deg, ${statusGrad[o.status][0]}22, ${statusGrad[o.status][1]}11)`,
                color: statusGrad[o.status][0], border: `1px solid ${statusGrad[o.status][0]}33`,
              }}>{o.status}</span>
              <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0 8px" }}>
                <div style={{ flex: 1, height: 5, background: "rgba(255,255,255,0.06)", borderRadius: 6, overflow: "hidden" }}>
                  <div style={{
                    width: loaded ? `${o.progress}%` : "0%", height: "100%", borderRadius: 6,
                    background: `linear-gradient(90deg, ${statusGrad[o.status][0]}, ${statusGrad[o.status][1]})`,
                    transition: `width 1s ease ${0.5 + idx * 0.12}s`,
                    boxShadow: `0 0 8px ${statusGrad[o.status][0]}44`,
                  }} />
                </div>
                <span style={{ fontSize: 11, color: "#64748B", minWidth: 30 }}>{o.progress}%</span>
              </div>
              <span style={{ color: "#64748B", fontSize: 12, textAlign: "right" }}>{o.due}</span>
            </div>
          ))}
        </Glass>
      </main>
    </div>
  );
}
