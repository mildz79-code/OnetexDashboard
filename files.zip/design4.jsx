import { useState, useEffect } from "react";
import { BarChart, Bar, AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

const profitData = [
  { month: "Aug", revenue: 42000, cost: 28000, profit: 14000 },
  { month: "Sep", revenue: 48000, cost: 30000, profit: 18000 },
  { month: "Oct", revenue: 51000, cost: 32000, profit: 19000 },
  { month: "Nov", revenue: 55000, cost: 31000, profit: 24000 },
  { month: "Dec", revenue: 62000, cost: 35000, profit: 27000 },
  { month: "Jan", revenue: 58000, cost: 33000, profit: 25000 },
  { month: "Feb", revenue: 67000, cost: 36000, profit: 31000 },
];

const orderData = [
  { id: "OT-4821", client: "Zara EU", style: "Linen Blazer", qty: 2400, status: "Cutting", progress: 35, due: "Mar 12" },
  { id: "OT-4822", client: "H&M Asia", style: "Cotton Tee V2", qty: 8000, status: "Sewing", progress: 62, due: "Mar 05" },
  { id: "OT-4823", client: "Uniqlo JP", style: "Fleece Pullover", qty: 5500, status: "QC", progress: 88, due: "Feb 28" },
  { id: "OT-4824", client: "Gap NA", style: "Denim Jacket", qty: 3200, status: "Packing", progress: 95, due: "Feb 27" },
  { id: "OT-4825", client: "Nike SG", style: "DryFit Polo", qty: 6000, status: "Fabric Prep", progress: 12, due: "Mar 22" },
];

const dailyProfit = [
  { d: "M", v: 4200 }, { d: "T", v: 5100 }, { d: "W", v: 4800 },
  { d: "T", v: 6200 }, { d: "F", v: 5900 }, { d: "S", v: 3100 },
];

const statusMap = {
  "Fabric Prep": { color: "#6366F1", bg: "#EEF2FF" },
  "Cutting": { color: "#EA580C", bg: "#FFF7ED" },
  "Sewing": { color: "#0891B2", bg: "#ECFEFF" },
  "QC": { color: "#059669", bg: "#ECFDF5" },
  "Packing": { color: "#D946EF", bg: "#FDF4FF" },
};

const menuItems = [
  { label: "Overview", active: true },
  { label: "Orders" },
  { label: "Production" },
  { label: "Patterns" },
  { label: "Materials" },
  { label: "Team" },
  { label: "Shipping" },
  { label: "Reports" },
  { label: "Settings" },
];

export default function Design4() {
  const [loaded, setLoaded] = useState(false);
  const [activeMenu, setActiveMenu] = useState("Overview");

  useEffect(() => { setLoaded(true); }, []);

  return (
    <div style={{
      fontFamily: "'Instrument Sans', 'Helvetica Neue', sans-serif",
      background: "#FAFAFA",
      color: "#18181B",
      minHeight: "100vh",
      display: "flex",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700;800&display=swap" rel="stylesheet" />

      {/* SIDEBAR */}
      <aside style={{
        width: 260,
        background: "#18181B",
        color: "#FAFAFA",
        display: "flex",
        flexDirection: "column",
        flexShrink: 0,
      }}>
        <div style={{ padding: "32px 28px 24px" }}>
          <div style={{ fontFamily: "'Playfair Display'", fontSize: 26, fontWeight: 700, letterSpacing: -0.5 }}>
            One<span style={{ color: "#EA580C" }}>Textile</span>
          </div>
          <div style={{ fontSize: 11, color: "#52525B", marginTop: 4, letterSpacing: 0.3 }}>Production Dashboard</div>
        </div>

        {/* Order Tracker WIP - Prominent */}
        <div style={{
          margin: "0 16px 12px",
          padding: "20px",
          background: "#27272A",
          borderRadius: 12,
          borderLeft: "4px solid #EA580C",
        }}>
          <div style={{ fontSize: 10, fontWeight: 600, color: "#EA580C", letterSpacing: 1.5, marginBottom: 10 }}>ORDER TRACKER</div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
            <div>
              <div style={{ fontFamily: "'Playfair Display'", fontSize: 40, fontWeight: 800, lineHeight: 1 }}>24</div>
              <div style={{ fontSize: 11, color: "#71717A", marginTop: 4 }}>active orders</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: "#22C55E" }}>18</div>
              <div style={{ fontSize: 10, color: "#71717A" }}>on track</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 4, marginTop: 14 }}>
            {[35, 62, 88, 95, 12].map((p, i) => (
              <div key={i} style={{ flex: 1, height: 3, borderRadius: 3, background: "#3F3F46", overflow: "hidden" }}>
                <div style={{ width: `${p}%`, height: "100%", background: "#EA580C", borderRadius: 3 }} />
              </div>
            ))}
          </div>
        </div>

        {/* Profit Tracker - Prominent */}
        <div style={{
          margin: "0 16px 24px",
          padding: "20px",
          background: "#27272A",
          borderRadius: 12,
          borderLeft: "4px solid #22C55E",
        }}>
          <div style={{ fontSize: 10, fontWeight: 600, color: "#22C55E", letterSpacing: 1.5, marginBottom: 10 }}>PROFIT TRACKER</div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
            <div>
              <div style={{ fontFamily: "'Playfair Display'", fontSize: 32, fontWeight: 800, lineHeight: 1 }}>$31K</div>
              <div style={{ fontSize: 11, color: "#71717A", marginTop: 4 }}>feb net profit</div>
            </div>
            <div style={{
              fontSize: 12, fontWeight: 600, color: "#22C55E",
              background: "#22C55E18", padding: "4px 10px", borderRadius: 6,
            }}>↑ 24%</div>
          </div>
          <div style={{ marginTop: 14, height: 40 }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailyProfit}>
                <defs>
                  <linearGradient id="miniGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#22C55E" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#22C55E" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <Area type="monotone" dataKey="v" stroke="#22C55E" fill="url(#miniGrad)" strokeWidth={1.5} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <nav style={{ flex: 1, padding: "0 12px" }}>
          {menuItems.map((item) => (
            <button
              key={item.label}
              onClick={() => setActiveMenu(item.label)}
              style={{
                display: "flex", alignItems: "center", gap: 12, width: "100%",
                padding: "11px 16px",
                background: activeMenu === item.label ? "#EA580C" : "transparent",
                border: "none", borderRadius: 8,
                color: activeMenu === item.label ? "#fff" : "#71717A",
                fontSize: 13, fontWeight: activeMenu === item.label ? 600 : 400,
                cursor: "pointer", marginBottom: 2, transition: "all 0.2s",
              }}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div style={{ padding: "20px 28px", borderTop: "1px solid #27272A" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: "#EA580C", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700 }}>OT</div>
            <div>
              <div style={{ fontSize: 12, fontWeight: 500 }}>Admin User</div>
              <div style={{ fontSize: 10, color: "#52525B" }}>admin@onetextile.com</div>
            </div>
          </div>
        </div>
      </aside>

      {/* MAIN */}
      <main style={{ flex: 1, padding: "32px 36px", overflow: "auto" }}>
        <div style={{
          opacity: loaded ? 1 : 0, transition: "opacity 0.5s",
        }}>
          {/* Header */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 36 }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 600, color: "#EA580C", letterSpacing: 2, marginBottom: 8 }}>DASHBOARD</div>
              <h1 style={{ fontFamily: "'Playfair Display'", fontSize: 38, fontWeight: 700, margin: 0, lineHeight: 1.1, letterSpacing: -1 }}>
                Production<br />Overview
              </h1>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 12, color: "#71717A" }}>February 26, 2026</div>
              <div style={{ display: "flex", gap: 6, alignItems: "center", marginTop: 8, justifyContent: "flex-end" }}>
                <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#22C55E" }} />
                <span style={{ fontSize: 11, color: "#22C55E", fontWeight: 500 }}>Systems operational</span>
              </div>
            </div>
          </div>

          {/* KPI Row */}
          <div style={{
            display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 28,
            opacity: loaded ? 1 : 0, transform: loaded ? "none" : "translateY(10px)", transition: "all 0.6s ease 0.1s",
          }}>
            {[
              { label: "Monthly Revenue", value: "$67,000", delta: "+15.3%", color: "#EA580C" },
              { label: "Net Profit", value: "$31,000", delta: "+24.0%", color: "#22C55E" },
              { label: "Units Produced", value: "5,700", delta: "+8.2%", color: "#0891B2" },
              { label: "Defect Rate", value: "1.2%", delta: "−0.3pp", color: "#6366F1" },
            ].map((k, i) => (
              <div key={i} style={{
                background: "#fff", borderRadius: 12, padding: "22px 20px",
                boxShadow: "0 1px 2px rgba(0,0,0,0.04)",
                borderBottom: `3px solid ${k.color}`,
              }}>
                <div style={{ fontSize: 11, color: "#71717A", fontWeight: 500, marginBottom: 10 }}>{k.label}</div>
                <div style={{ fontFamily: "'Playfair Display'", fontSize: 30, fontWeight: 700, lineHeight: 1, letterSpacing: -1 }}>{k.value}</div>
                <div style={{ fontSize: 12, color: k.color, fontWeight: 600, marginTop: 10 }}>{k.delta}</div>
              </div>
            ))}
          </div>

          {/* Charts Row */}
          <div style={{
            display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 28,
            opacity: loaded ? 1 : 0, transition: "all 0.7s ease 0.2s",
          }}>
            {/* Profit Chart */}
            <div style={{ background: "#fff", borderRadius: 12, padding: 24, boxShadow: "0 1px 2px rgba(0,0,0,0.04)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                <div style={{ fontSize: 15, fontWeight: 600 }}>Profit Analysis</div>
                <div style={{ display: "flex", gap: 14, fontSize: 11 }}>
                  <span style={{ color: "#EA580C", fontWeight: 500 }}>● Revenue</span>
                  <span style={{ color: "#22C55E", fontWeight: 500 }}>● Profit</span>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={profitData}>
                  <defs>
                    <linearGradient id="g4rev" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#EA580C" stopOpacity={0.15} />
                      <stop offset="100%" stopColor="#EA580C" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="g4prof" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#22C55E" stopOpacity={0.15} />
                      <stop offset="100%" stopColor="#22C55E" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="month" tick={{ fill: "#A1A1AA", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#A1A1AA", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v/1000}k`} />
                  <Tooltip contentStyle={{ background: "#fff", border: "1px solid #E4E4E7", borderRadius: 8, fontSize: 12, boxShadow: "0 4px 12px rgba(0,0,0,0.08)" }} />
                  <Area type="monotone" dataKey="revenue" stroke="#EA580C" fill="url(#g4rev)" strokeWidth={2} />
                  <Area type="monotone" dataKey="profit" stroke="#22C55E" fill="url(#g4prof)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Production Pipeline */}
            <div style={{ background: "#fff", borderRadius: 12, padding: 24, boxShadow: "0 1px 2px rgba(0,0,0,0.04)" }}>
              <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 20 }}>Production Pipeline</div>
              {[
                { stage: "Fabric Prep", count: 4, total: 24 },
                { stage: "Cutting", count: 6, total: 24 },
                { stage: "Sewing", count: 8, total: 24 },
                { stage: "QC", count: 3, total: 24 },
                { stage: "Packing", count: 3, total: 24 },
              ].map((s, i) => (
                <div key={i} style={{ marginBottom: 18 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 12, fontWeight: 500, color: statusMap[s.stage]?.color }}>{s.stage}</span>
                    <span style={{ fontSize: 12, color: "#71717A" }}>{s.count} orders</span>
                  </div>
                  <div style={{ height: 8, background: "#F4F4F5", borderRadius: 8, overflow: "hidden" }}>
                    <div style={{
                      width: loaded ? `${(s.count / s.total) * 100}%` : "0%", height: "100%",
                      background: statusMap[s.stage]?.color, borderRadius: 8,
                      transition: `width 0.8s ease ${0.3 + i * 0.1}s`,
                    }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Order Table */}
          <div style={{
            background: "#fff", borderRadius: 12, padding: 0, boxShadow: "0 1px 2px rgba(0,0,0,0.04)", overflow: "hidden",
            opacity: loaded ? 1 : 0, transition: "all 0.8s ease 0.3s",
          }}>
            <div style={{ padding: "22px 24px 16px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #F4F4F5" }}>
              <div>
                <div style={{ fontSize: 15, fontWeight: 600 }}>Active Orders</div>
                <div style={{ fontSize: 11, color: "#A1A1AA", marginTop: 2 }}>Work in progress — real-time tracking</div>
              </div>
              <button style={{
                border: "1px solid #E4E4E7", background: "transparent", borderRadius: 8,
                padding: "8px 16px", fontSize: 12, fontWeight: 500, cursor: "pointer", color: "#18181B",
              }}>Export ↗</button>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ background: "#FAFAFA" }}>
                  {["Order", "Client", "Style", "Qty", "Status", "Progress", "Due"].map(h => (
                    <th key={h} style={{ textAlign: "left", padding: "12px 16px", fontSize: 10, fontWeight: 600, color: "#A1A1AA", letterSpacing: 1, borderBottom: "1px solid #F4F4F5" }}>{h.toUpperCase()}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {orderData.map((o, idx) => (
                  <tr key={o.id} style={{ borderBottom: idx < orderData.length - 1 ? "1px solid #F9F9F9" : "none", transition: "background 0.15s" }}
                    onMouseEnter={e => e.currentTarget.style.background = "#FAFAFA"}
                    onMouseLeave={e => e.currentTarget.style.background = "transparent"}
                  >
                    <td style={{ padding: "14px 16px", fontWeight: 600, color: "#EA580C", fontSize: 13 }}>{o.id}</td>
                    <td style={{ padding: "14px 16px", fontWeight: 500, fontSize: 13 }}>{o.client}</td>
                    <td style={{ padding: "14px 16px", color: "#71717A", fontSize: 13 }}>{o.style}</td>
                    <td style={{ padding: "14px 16px", fontSize: 13 }}>{o.qty.toLocaleString()}</td>
                    <td style={{ padding: "14px 16px" }}>
                      <span style={{
                        display: "inline-block", padding: "4px 12px", borderRadius: 6, fontSize: 11, fontWeight: 600,
                        background: statusMap[o.status]?.bg, color: statusMap[o.status]?.color,
                      }}>{o.status}</span>
                    </td>
                    <td style={{ padding: "14px 16px", width: 160 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div style={{ flex: 1, height: 6, background: "#F4F4F5", borderRadius: 6, overflow: "hidden" }}>
                          <div style={{
                            width: loaded ? `${o.progress}%` : "0%", height: "100%",
                            background: statusMap[o.status]?.color, borderRadius: 6,
                            transition: `width 0.8s ease ${0.5 + idx * 0.1}s`,
                          }} />
                        </div>
                        <span style={{ fontSize: 11, color: "#A1A1AA", minWidth: 30 }}>{o.progress}%</span>
                      </div>
                    </td>
                    <td style={{ padding: "14px 16px", color: "#A1A1AA", fontSize: 12 }}>{o.due}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
